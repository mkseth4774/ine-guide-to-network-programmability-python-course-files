from __future__ import unicode_literals
from netmiko.terminal_server.terminal_server import TerminalServerSSH
from netmiko.terminal_server.terminal_server import TerminalServerTelnet

__all__ = ['TerminalServerSSH', 'TerminalServerTelnet']
