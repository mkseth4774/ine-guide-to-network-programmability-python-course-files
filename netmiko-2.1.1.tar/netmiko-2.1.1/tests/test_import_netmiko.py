from netmiko import ConnectHandler

def test_placeholder():
    assert True
