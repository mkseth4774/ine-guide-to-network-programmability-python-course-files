BaseConnection
==============

.. autoclass:: netmiko.base_connection.BaseConnection
    :members:
    :special-members:
